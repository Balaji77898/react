import FigureList from "./FigureList";
function App() {
  return (
    <div>
      <FigureList/>
    </div>
  );
}
export default App;