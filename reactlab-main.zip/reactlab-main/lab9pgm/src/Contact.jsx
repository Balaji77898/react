import React from 'react';

function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Have questions? Reach out to us through this page!</p>
    </div>
  );
}

export default Contact;
