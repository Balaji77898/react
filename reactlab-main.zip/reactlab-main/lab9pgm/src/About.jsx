import React from 'react';

function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>This page tells you more about our team and mission.</p>
    </div>
  );
}

export default About;
