import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to the Home Page</h1>
      <p>This is the homepage of our awesome React app.</p>
    </div>
  );
}

export default Home;
